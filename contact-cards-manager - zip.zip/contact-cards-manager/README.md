# Contact Cards Manager (React SPA)

## Run it
1. Install Node.js (https://nodejs.org) if you don't have it.
2. In this folder, run:

       npm install
       npm run dev

3. Open the link shown in the terminal (usually http://localhost:5173).

## Structure
- src/index.jsx              - entry point
- src/App.jsx                - main component: useState for contacts + search, filtering
- src/components/ContactForm.jsx - controlled form, validation, submit
- src/components/ContactCard.jsx - reusable card
- src/components/ContactList.jsx - responsive grid of cards
- src/App.css                - styling (shadow, rounded corners, hover effects)
