import { useState } from "react";

function getInitials(name) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0].toUpperCase())
    .join("");
}

function ContactCard({ contact, onDelete }) {
  const { id, name, title, company, phone, email, bio, avatar } = contact;
  // If the avatar URL fails to load, fall back to initials
  const [imgFailed, setImgFailed] = useState(false);

  return (
    <article className="contact-card">
      <button
        className="delete-btn"
        onClick={() => onDelete(id)}
        aria-label={`Delete ${name}`}
        title="Delete contact"
      >
        ×
      </button>

      {avatar && !imgFailed ? (
        <img
          className="avatar"
          src={avatar}
          alt={name}
          onError={() => setImgFailed(true)}
        />
      ) : (
        <div className="avatar avatar-initials">{getInitials(name)}</div>
      )}

      <h3>{name}</h3>
      <p className="card-role">
        {title && <span>{title}</span>}
        {title && company && <span> · </span>}
        <strong>{company}</strong>
      </p>

      {bio && <p className="card-bio">{bio}</p>}

      <ul className="card-info">
        {phone && <li>📞 {phone}</li>}
        {email && <li>✉️ {email}</li>}
      </ul>
    </article>
  );
}

export default ContactCard;
