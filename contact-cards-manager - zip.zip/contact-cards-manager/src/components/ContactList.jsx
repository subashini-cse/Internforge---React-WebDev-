import ContactCard from "./ContactCard.jsx";

function ContactList({ contacts, onDelete, isSearching }) {
  if (contacts.length === 0) {
    return (
      <p className="empty-state">
        {isSearching
          ? "No contacts match your search."
          : "No contacts yet. Add your first one using the form!"}
      </p>
    );
  }

  return (
    <div className="contact-grid">
      {contacts.map((contact) => (
        <ContactCard key={contact.id} contact={contact} onDelete={onDelete} />
      ))}
    </div>
  );
}

export default ContactList;
