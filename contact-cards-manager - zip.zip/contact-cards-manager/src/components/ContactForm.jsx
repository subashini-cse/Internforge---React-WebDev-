import { useState } from "react";

const EMPTY_FORM = {
  name: "",
  title: "",
  company: "",
  phone: "",
  email: "",
  bio: "",
  avatar: "",
};

function ContactForm({ onAddContact }) {
  const [form, setForm] = useState(EMPTY_FORM);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!form.name.trim() || !form.company.trim()) {
      setError("Full name and company are required.");
      return;
    }
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim())) {
      setError("Please enter a valid email address.");
      return;
    }

    onAddContact({
      name: form.name.trim(),
      title: form.title.trim(),
      company: form.company.trim(),
      phone: form.phone.trim(),
      email: form.email.trim(),
      bio: form.bio.trim(),
      avatar: form.avatar.trim(),
    });

    setForm(EMPTY_FORM);
    setError("");
  };

  return (
    <form className="contact-form" onSubmit={handleSubmit} noValidate>
      <h2>Add New Contact</h2>

      <label>
        Full Name *
        <input name="name" value={form.name} onChange={handleChange} placeholder="e.g. Subashini" />
      </label>

      <label>
        Job Title
        <input name="title" value={form.title} onChange={handleChange} placeholder="e.g. Frontend Developer" />
      </label>

      <label>
        Company *
        <input name="company" value={form.company} onChange={handleChange} placeholder="e.g. TechSoft" />
      </label>

      <label>
        Phone
        <input name="phone" type="tel" value={form.phone} onChange={handleChange} placeholder="+91 90000 00000" />
      </label>

      <label>
        Email
        <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="name@example.com" />
      </label>

      <label>
        Short Bio
        <textarea name="bio" rows="3" value={form.bio} onChange={handleChange} placeholder="A line or two about this person..." />
      </label>

      <label>
        Avatar URL (optional)
        <input name="avatar" value={form.avatar} onChange={handleChange} placeholder="https://..." />
      </label>

      {error && <p className="form-error">{error}</p>}

      <button type="submit" className="btn-primary">Add Contact</button>
    </form>
  );
}

export default ContactForm;
