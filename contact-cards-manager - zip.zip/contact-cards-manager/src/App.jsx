import { useState } from "react";
import ContactForm from "./components/ContactForm.jsx";
import ContactList from "./components/ContactList.jsx";

const INITIAL_CONTACTS = [
  {
    id: 1,
    name: "Priya Sharma",
    title: "UI/UX Designer",
    company: "Pixel Studio",
    phone: "+91 98765 43210",
    email: "priya@pixelstudio.com",
    bio: "Designs clean, accessible interfaces for web and mobile apps.",
    avatar: "",
  },
  {
    id: 2,
    name: "Arjun Mehta",
    title: "Full Stack Developer",
    company: "CodeNest",
    phone: "+91 91234 56789",
    email: "arjun@codenest.io",
    bio: "Loves building scalable apps with React and Node.js.",
    avatar: "",
  },
  {
    id: 3,
    name: "Meena Iyer",
    title: "Product Manager",
    company: "BrightApps",
    phone: "+91 99887 77665",
    email: "meena@brightapps.com",
    bio: "Turns customer feedback into simple, useful products.",
    avatar: "",
  },
];

function App() {
  // State holding the array of contacts
  const [contacts, setContacts] = useState(INITIAL_CONTACTS);
  // Controlled search input
  const [searchTerm, setSearchTerm] = useState("");

  const addContact = (contact) => {
    setContacts((prev) => [{ ...contact, id: Date.now() }, ...prev]);
  };

  const deleteContact = (id) => {
    setContacts((prev) => prev.filter((c) => c.id !== id));
  };

  // Derived state: filter by name OR company (case-insensitive, partial match)
  const term = searchTerm.trim().toLowerCase();
  const filteredContacts = contacts.filter(
    (c) =>
      c.name.toLowerCase().includes(term) ||
      c.company.toLowerCase().includes(term)
  );

  return (
    <div className="app">
      <header className="app-header">
        <h1>📇 Contact Cards Manager</h1>
        <p>Add contacts and search them instantly.</p>
      </header>

      <main className="app-main">
        <aside className="form-panel">
          <ContactForm onAddContact={addContact} />
        </aside>

        <section className="list-panel">
          <div className="search-bar">
            <input
              type="text"
              placeholder="🔍 Search by name or company..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              aria-label="Search contacts"
            />
            <span className="count">
              {filteredContacts.length} of {contacts.length}
            </span>
          </div>

          <ContactList
            contacts={filteredContacts}
            onDelete={deleteContact}
            isSearching={term !== ""}
          />
        </section>
      </main>
    </div>
  );
}

export default App;
